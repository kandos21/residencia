	<html>
	<head>
	<title>Inicio de sesi�n</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>
	<body>
	<form action="control.php" method="post" id="form"><br>
	Usuario: <input type="text" name="usuario" id="usuario" /><br>
	Clave: <input type="password" name="clave" id="clave" /><br>
	<input type="submit" value="Entrar">
	</form>
	</body>
	</html>
